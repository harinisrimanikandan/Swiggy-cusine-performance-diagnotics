-- 02_aggregation_joins.sql
SELECT r.cuisine, COUNT(o.order_id) AS order_count,
       SUM(o.amount_inr) AS total_revenue,
       AVG(o.amount_inr) AS avg_revenue
FROM orders o
INNER JOIN restaurants r ON o.restaurant_id = r.restaurant_id
WHERE o.status = 'Delivered'
GROUP BY r.cuisine
HAVING SUM(o.amount_inr) > 40000
ORDER BY total_revenue DESC;

SELECT r.restaurant_id, r.name, r.cuisine,
       COUNT(o.order_id) AS total_orders
FROM restaurants r
LEFT JOIN orders o ON r.restaurant_id = o.restaurant_id
GROUP BY r.restaurant_id, r.name, r.cuisine
ORDER BY total_orders ASC, r.restaurant_id;
