# Swiggy Cuisine Performance Diagnostic

## Files

- `generate_data.py` — deterministic SQLite data generator
- `swiggy_capstone.db` — generated SQLite database
- `verify.sql` — row-count/status verification
- `01_foundations.sql` — SELECT/WHERE/DISTINCT/ORDER BY/LIMIT/LIKE/IN/BETWEEN/NULL
- `02_aggregation_joins.sql` — INNER JOIN, LEFT JOIN, GROUP BY, HAVING
- `03_reporting.sql` — restaurant tiers, monthly cuisine revenue, target variance
- `export_csv.py` — CSV export script
- `monthly_cuisine_revenue.csv` — fixed dataset for spreadsheet/Tableau
- `swiggy_cuisine_analysis.xlsx` — spreadsheet analysis
- `ai_log.md` — RCTCF prompts and verification placeholders
- `DATA_STORY.md` — dashboard data-story template

## Data Lineage

`generate_data.py` → `swiggy_capstone.db` → `03_reporting.sql` → `monthly_cuisine_revenue.csv` → spreadsheet/Tableau.

## Tableau Public

PASTE YOUR ACTUAL TABLEAU PUBLIC URL HERE

## Important

The AI verification fields and Tableau URL must be replaced with the student's actual actions/results before submission.
