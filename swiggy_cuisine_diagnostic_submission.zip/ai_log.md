# AI-Assisted Prompting Log

## Prompt 1 — SQL Diagnostic

### Role
You are a SQL analyst experienced with SQLite and business-revenue reporting.

### Context
I am working on a deterministic Swiggy-style SQLite database containing restaurants, customers, orders, and cuisine_targets. Delivered orders represent revenue. I need a cuisine-level revenue query that joins orders to restaurants and calculates revenue by cuisine.

### Task
Help me draft or debug a SQLite query that calculates total Delivered revenue by cuisine and joins the result to cuisine_targets to calculate variance, percentage variance, and target status.

### Constraints
Use SQLite syntax. Do not change the underlying data. Percentage variance must use floating-point division, such as ((total_revenue - target_revenue_inr) * 100.0) / target_revenue_inr. Target status must be Above Target when revenue is at least the target, Below Target - Watch when the shortfall is within 15%, and Below Target - Critical otherwise.

### Format
Return one runnable SQL query followed by a short explanation of each calculated field.

### Verification
[Replace this with the verification you actually performed.]

## Prompt 2 — Tableau/Data Story

### Role
You are a Tableau data-storytelling analyst helping a category-management team interpret restaurant cuisine revenue.

### Context
I have a fixed CSV containing monthly Delivered revenue by cuisine for January through June 2026. The six cuisines are North Indian, South Indian, Chinese, Italian, Fast Food, and Desserts. My dashboard contains a monthly revenue trend, a cuisine revenue bar chart, KPI cards, and a target-status classification.

### Task
Help me draft a concise data story for the dashboard and suggest two concrete category-management recommendations based only on the revenue-versus-target results.

### Constraints
Do not invent data, causes, customer behavior, or operational explanations. Use only figures that I provide from my SQL/spreadsheet/Tableau results. The recommendations must be concrete and directly grounded in the observed numbers.

### Format
Provide a short paragraph interpreting the results followed by exactly two numbered recommendations.

### Verification
[Replace this with the verification you actually performed.]
