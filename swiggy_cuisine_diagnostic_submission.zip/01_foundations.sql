-- 01_foundations.sql
SELECT restaurant_id, name, cuisine, city
FROM restaurants WHERE city = 'Mumbai';

SELECT DISTINCT cuisine FROM restaurants ORDER BY cuisine;

SELECT order_id, customer_id, restaurant_id, order_date, amount_inr, status
FROM orders ORDER BY amount_inr DESC LIMIT 5;

SELECT restaurant_id, name, cuisine, city
FROM restaurants WHERE name LIKE '%Spice%';

SELECT customer_id, name, signup_date, city
FROM customers WHERE city IN ('Mumbai', 'Delhi')
ORDER BY city, customer_id;

SELECT order_id, order_date, amount_inr, status
FROM orders WHERE amount_inr BETWEEN 500 AND 1500
ORDER BY amount_inr;

SELECT order_id, order_date, amount_inr, status
FROM orders WHERE amount_inr NOT BETWEEN 500 AND 1500
ORDER BY amount_inr;

SELECT order_id, order_date, amount_inr, status, rating
FROM orders WHERE rating IS NULL ORDER BY order_id;
