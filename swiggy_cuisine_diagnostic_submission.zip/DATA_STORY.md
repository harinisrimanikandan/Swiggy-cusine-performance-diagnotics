# Swiggy Cuisine Performance Data Story

## Performance Against Target

The spreadsheet `Cuisine Summary` and SQL report contain the reconciled cuisine-level revenue results. Replace the bracketed fields below with the values you actually use in your submitted dashboard.

| Cuisine | Total Revenue (INR) | Target (INR) | Variance (INR) | Status |
|---|---:|---:|---:|---|
| North Indian | [VALUE] | 180000 | [VALUE] | [STATUS] |
| South Indian | [VALUE] | 50000 | [VALUE] | [STATUS] |
| Chinese | [VALUE] | 140000 | [VALUE] | [STATUS] |
| Italian | [VALUE] | 10000 | [VALUE] | [STATUS] |
| Fast Food | [VALUE] | 60000 | [VALUE] | [STATUS] |
| Desserts | [VALUE] | 25000 | [VALUE] | [STATUS] |

## Data Story

Use only the actual SQL/Tableau values. Do not invent causes that are not represented in the data.

North Indian, South Indian, and Italian are expected to be evaluated against their targets using the SQL target-variance report. The dashboard should identify which cuisines are above target and which are below target, with the largest absolute shortfall highlighted.

## Recommendations

1. **[Cuisine / action based on actual result]** — state the concrete action and cite the actual revenue/target gap.

2. **[Cuisine / action based on actual result]** — state the concrete action and cite the actual revenue/target gap.
